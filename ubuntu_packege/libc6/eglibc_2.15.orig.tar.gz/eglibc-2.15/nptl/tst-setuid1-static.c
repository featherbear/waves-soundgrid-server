#include "tst-setuid1.c"
