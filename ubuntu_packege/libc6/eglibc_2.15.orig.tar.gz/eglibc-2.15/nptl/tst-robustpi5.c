#define ENABLE_PI 1
#include "tst-robust5.c"
