#define ENABLE_PI 1
#include "tst-mutex2.c"
