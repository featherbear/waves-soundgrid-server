/* This is overridden by generated tcb-offsets.h on arches which need it.  */
