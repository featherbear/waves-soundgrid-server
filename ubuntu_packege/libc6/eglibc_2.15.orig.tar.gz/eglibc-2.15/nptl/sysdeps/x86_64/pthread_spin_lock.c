#include "../i386/pthread_spin_lock.c"
