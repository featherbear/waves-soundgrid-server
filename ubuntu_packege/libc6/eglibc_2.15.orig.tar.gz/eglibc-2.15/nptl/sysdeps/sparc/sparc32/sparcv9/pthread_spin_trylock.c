#include <sparc64/pthread_spin_trylock.c>
