#include <sparc64/pthread_spin_unlock.c>
