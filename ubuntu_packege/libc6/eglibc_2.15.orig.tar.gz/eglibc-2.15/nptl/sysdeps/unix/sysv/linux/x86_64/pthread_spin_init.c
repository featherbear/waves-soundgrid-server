#include <nptl/sysdeps/x86_64/pthread_spin_init.c>
