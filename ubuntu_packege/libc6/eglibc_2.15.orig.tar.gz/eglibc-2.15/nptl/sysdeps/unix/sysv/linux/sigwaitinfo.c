#include <nptl/pthreadP.h>
#include "../../../../../sysdeps/unix/sysv/linux/sigwaitinfo.c"
