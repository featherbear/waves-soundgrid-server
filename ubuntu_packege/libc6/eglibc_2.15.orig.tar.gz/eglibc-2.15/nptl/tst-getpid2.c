#define TEST_CLONE_FLAGS CLONE_VM
#include "tst-getpid1.c"
