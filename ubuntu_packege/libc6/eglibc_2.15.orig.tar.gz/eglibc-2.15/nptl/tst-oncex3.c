#include "tst-once3.c"
