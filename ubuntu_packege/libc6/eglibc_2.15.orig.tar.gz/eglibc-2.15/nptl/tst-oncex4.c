#include "tst-once4.c"
