#define SINGLE_THREAD
#define __setresuid pthread_setresuid_np
#include <setresuid.c>
