#define TYPE long
#define NAME atol
#include "atox.c"
