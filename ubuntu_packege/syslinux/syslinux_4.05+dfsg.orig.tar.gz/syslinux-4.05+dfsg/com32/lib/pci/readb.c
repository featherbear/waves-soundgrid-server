#define TYPE uint8_t
#define BWL(x) x ## b
#define BIOSCALL 0xb108
#include "pci/readx.c"
